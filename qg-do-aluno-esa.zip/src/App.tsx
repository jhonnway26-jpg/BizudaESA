/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { 
  Contact, LogIn, VolumeX, Volume2, Cloud, Flame, ShieldCheck, 
  Satellite, Target, Hourglass, Signal, Globe, CloudDownload, 
  Timer, Play, Pause, Brain, Pin, RotateCw, FileText, Send, 
  User, Bot, X, TriangleAlert, Star, ArrowUp, UserPlus
} from 'lucide-react';
import { 
  signInAnonymously, onAuthStateChanged, User as FirebaseUser 
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db } from './lib/firebase';
import { generateDossie, chatGemini } from './services/gemini';
import { ProgressoAluno, Questao, DossieMissao } from './types';
import { cn, playSfxClick, playSfxCorrect, playSfxWrong, playSfxLevelUp, falarTexto, initSFX } from './lib/utils';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer } from 'recharts';

const INITIAL_PROGRESS: ProgressoAluno = {
  totalVistos: 0,
  materias: {},
  acertos: 0,
  erros: 0,
  streak: 0,
  lastStudyDate: null
};

const PATENTES = [
  { nome: 'Recruta', max: 5 }, { nome: 'Soldado', max: 15 },
  { nome: 'Cabo', max: 30 }, { nome: '3º Sargento', max: 50 },
  { nome: '2º Sargento', max: 80 }, { nome: '1º Sargento', max: 999 }
];

const TEMPOS = {
  curto: { min: 30, teoria: "30 min", pratica: "45 min", revisao: "15 min", label: "Ataque Rápido (30 min foco)" },
  medio: { min: 60, teoria: "1h", pratica: "2h", revisao: "30 min", label: "Operação Padrão (60 min foco)" },
  longo: { min: 120, teoria: "1h 30m", pratica: "3h", revisao: "45 min", label: "Missão Caveira (120 min foco)" }
};

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [progresso, setProgresso] = useState<ProgressoAluno>(INITIAL_PROGRESS);
  const [isRadioPlaying, setIsRadioPlaying] = useState(false);
  const [streakDisplay, setStreakDisplay] = useState("0 Dias");
  
  // Modals state
  const [showFicha, setShowFicha] = useState(false);
  const [showAlert, setShowAlert] = useState<{show: boolean, msg: string}>({show: false, msg: ""});
  const [showAuth, setShowAuth] = useState(false);
  const [isLoginMode, setIsLoginMode] = useState(true);

  // Form State
  const [materia, setMateria] = useState('matematica');
  const [tempo, setTempo] = useState<keyof typeof TEMPOS>('medio');
  
  // Generation State
  const [isLoading, setIsLoading] = useState(false);
  const [missao, setMissao] = useState<DossieMissao | null>(null);
  const [showLevelUp, setShowLevelUp] = useState(false);
  
  // Timer State
  const [tempoRestante, setTempoRestante] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Chat State
  const [showChat, setShowChat] = useState(false);
  const [chatMsgs, setChatMsgs] = useState<{role: 'user'|'ia', text: string, id: string}[]>([
    {role: 'ia', text: '**Brasil!** Estou conectado à rede para organizar o seu papiro.\n\nQual é a sua dúvida operacional?', id: 'initial'}
  ]);
  const [chatInput, setChatInput] = useState("");
  const [isChatLoading, setIsChatLoading] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Radio Audio Context
  const audioRefs = useRef<{ctx?: AudioContext, noise?: AudioBufferSourceNode, gain?: GainNode}>({});

  useEffect(() => {
    // Init Local Storage & Firebase
    const rawLocal = localStorage.getItem('esa_qg_progresso');
    if (rawLocal) {
        try { setProgresso(p => ({...p, ...JSON.parse(rawLocal)})); } catch(e) {}
    }

    onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        const docRef = doc(db, 'users', u.uid);
        const snap = await getDoc(docRef);
        if (snap.exists() && snap.data().data) {
          setProgresso(snap.data().data);
        }
      }
    });

    handleStreak();
  }, []);

  useEffect(() => {
    localStorage.setItem('esa_qg_progresso', JSON.stringify(progresso));
    if (user && !user.isAnonymous) {
       setDoc(doc(db, 'users', user.uid), { data: progresso }, { merge: true });
    }
  }, [progresso]);

  useEffect(() => {
    if(chatBottomRef.current) chatBottomRef.current.scrollIntoView({ behavior: 'smooth'});
  }, [chatMsgs]);

  const handleStreak = () => {
    const today = new Date().toDateString();
    setProgresso(prev => {
        let newProg = {...prev};
        if (newProg.lastStudyDate !== today) {
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            if (newProg.lastStudyDate === yesterday.toDateString()) {
                // Keep streak
            } else if (newProg.lastStudyDate) {
                newProg.streak = 0;
            }
        }
        setStreakDisplay(`${newProg.streak || 0} Dias`);
        return newProg;
    });
  };

  const advanceStreak = () => {
    const today = new Date().toDateString();
    setProgresso(prev => {
        if (prev.lastStudyDate !== today) {
            const updated = {...prev, streak: (prev.streak || 0) + 1, lastStudyDate: today};
            setStreakDisplay(`${updated.streak} Dias`);
            return updated;
        }
        return prev;
    });
  };

  const toggleRadio = () => {
    initSFX();
    let { ctx, noise, gain } = audioRefs.current;
    
    if (isRadioPlaying) {
      if (ctx) ctx.suspend();
      setIsRadioPlaying(false);
    } else {
      if (!ctx) {
        const AudioC = window.AudioContext || (window as any).webkitAudioContext;
        ctx = new AudioC();
        let bufferSize = 2 * ctx.sampleRate;
        let noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        let output = noiseBuffer.getChannelData(0);
        let lastOut = 0;
        for (let i = 0; i < bufferSize; i++) {
            let white = Math.random() * 2 - 1;
            output[i] = (lastOut + (0.02 * white)) / 1.02;
            lastOut = output[i];
            output[i] *= 3.5;
        }
        noise = ctx.createBufferSource();
        noise.buffer = noiseBuffer;
        noise.loop = true;
        gain = ctx.createGain();
        gain.gain.value = 0.4;
        noise.connect(gain);
        gain.connect(ctx.destination);
        noise.start(0);
        audioRefs.current = { ctx, noise, gain };
      }
      ctx.resume();
      setIsRadioPlaying(true);
    }
  };

  const handleGenerate = async () => {
    playSfxClick();
    setIsLoading(true);
    setMissao(null);
    setShowLevelUp(false);
    
    const matName = document.getElementById('select-materia')?.querySelector('option:checked')?.textContent || materia;
    const currentLvl = progresso.materias[materia]?.currentLevel || 'BÁSICO';
    const seen = progresso.materias[materia]?.seen || [];

    try {
      const data = await generateDossie(matName, currentLvl, seen);
      advanceStreak();
      
      let leveledUp = false;
      setProgresso(prev => {
         const pMat = prev.materias[materia] || { seen: [], currentLevel: 'BÁSICO' };
         if (!pMat.seen.includes(data.topico)) {
            const newSeen = [...pMat.seen, data.topico];
            let newLvl = pMat.currentLevel;
            if (newSeen.length >= 8) newLvl = 'CAVEIRA';
            else if (newSeen.length >= 4) newLvl = 'PADRÃO';
            else newLvl = 'BÁSICO';
            
            leveledUp = (pMat.currentLevel !== newLvl);
            if (leveledUp) playSfxLevelUp();
            
            return {
                ...prev,
                totalVistos: (prev.totalVistos || 0) + 1,
                materias: { ...prev.materias, [materia]: { seen: newSeen, currentLevel: newLvl } }
            }
         }
         return prev;
      });
      
      setShowLevelUp(leveledUp);
      setMissao(data);
      resetTimer(TEMPOS[tempo].min);
      playSfxCorrect();
    } catch (e: any) {
      setShowAlert({show: true, msg: e.message});
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuestao = (idx: number, selecionada: string, correta: string) => {
    const qBox = document.getElementById(`q-box-${idx}`);
    if (qBox?.dataset.respondida === "true") return;
    if (qBox) qBox.dataset.respondida = "true";

    const acertou = selecionada.toLowerCase() === correta.toLowerCase();
    if(acertou) {
        playSfxCorrect();
        setProgresso(prev => ({...prev, acertos: (prev.acertos||0) + 1}));
    } else {
        playSfxWrong();
        setProgresso(prev => ({...prev, erros: (prev.erros||0) + 1}));
    }

    ['a','b','c','d','e'].forEach(l => {
        const el = document.getElementById(`opt-${idx}-${l}`);
        if(el) {
            el.style.pointerEvents = 'none';
            if(l === correta.toLowerCase()) {
                el.classList.add('border-green-500', 'bg-green-900/30', 'text-white');
            } else if (l === selecionada.toLowerCase() && l !== correta.toLowerCase()) {
                el.classList.add('border-red-500', 'bg-red-900/30', 'text-red-200');
            }
        }
    });

    const exp = document.getElementById(`exp-${idx}`);
    if(exp) exp.classList.remove('hidden');
  };

  const resetTimer = (mins: number) => {
    if (timerRef.current) clearInterval(timerRef.current);
    setTempoRestante(mins * 60);
    setIsTimerRunning(false);
  };

  const toggleTimer = () => {
    playSfxClick();
    if(tempoRestante <= 0) return;
    if (isTimerRunning) {
        if (timerRef.current) clearInterval(timerRef.current);
        setIsTimerRunning(false);
    } else {
        setIsTimerRunning(true);
        timerRef.current = setInterval(() => {
            setTempoRestante(prev => {
                if (prev <= 1) {
                    clearInterval(timerRef.current!);
                    setIsTimerRunning(false);
                    setShowAlert({show: true, msg: "TEMPO ESGOTADO, GUERREIRO! Passe para a próxima fase da missão."});
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const sendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    playSfxClick();
    const msg = chatInput.trim();
    setChatInput("");
    setChatMsgs(prev => [...prev, {role: 'user', text: msg, id: Date.now().toString()}]);
    setIsChatLoading(true);

    try {
        const response = await chatGemini(msg);
        setChatMsgs(prev => [...prev, {role: 'ia', text: response.replace(/\*|#/g, ''), id: (Date.now()+1).toString()}]);
        falarTexto(response.replace(/\*|#/g, ''));
    } catch(e: any) {
        setChatMsgs(prev => [...prev, {role: 'ia', text: e.message, id: (Date.now()+1).toString()}]);
    } finally {
        setIsChatLoading(false);
    }
  };

  const getCurrentPatente = () => {
    const total = progresso.totalVistos || 0;
    let curr = PATENTES[0];
    let prevMax = 0;
    for(let p of PATENTES) {
        if(total <= p.max) return { ...p, prevMax };
        prevMax = p.max;
    }
    return { ...PATENTES[PATENTES.length-1], prevMax };
  };
  const patenteData = getCurrentPatente();

  const getRadarData = () => {
    const keys = ['matematica', 'portugues', 'literatura', 'redacao', 'historia', 'geografia', 'ingles'];
    const labels = ['Matem.', 'Portug.', 'Literat.', 'Redação', 'História', 'Geografia', 'Inglês'];
    return keys.map((k, i) => ({
        subject: labels[i],
        A: progresso.materias[k]?.seen?.length || 0,
        fullMark: 10
    }));
  };

  return (
    <div className="min-h-screen p-4 md:p-8 flex flex-col items-center justify-center relative">
        <div className="bg-grid"></div>

        {/* Top Bar */}
        <div className="absolute top-4 left-4 right-4 flex justify-between items-center z-20 no-print flex-wrap gap-2">
            <div className="flex gap-2">
                <button onClick={() => setShowFicha(true)} className="bg-slate-900 border border-slate-700 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-slate-800 transition-colors shadow-lg">
                    <Contact className="w-4 h-4 text-green-500" /> <span className="hidden md:inline">Ficha Militar</span>
                </button>
                <button onClick={() => setShowAuth(true)} className="bg-slate-900 border border-slate-700 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-slate-800 transition-colors shadow-lg">
                    {user ? <LogIn className="w-4 h-4 text-red-400"/> : <LogIn className="w-4 h-4 text-blue-400"/>} 
                    <span className="hidden md:inline">{user ? "Sair" : "Entrar / Alistar"}</span>
                </button>
                <button onClick={toggleRadio} className={cn("bg-slate-900 border border-slate-700 px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-slate-800 transition-colors shadow-lg", isRadioPlaying ? "text-white animate-pulse" : "text-slate-400 hover:text-white")}>
                    {isRadioPlaying ? <Volume2 className="w-4 h-4 text-green-400"/> : <VolumeX className="w-4 h-4 text-blue-400"/>} 
                    <span className="hidden md:inline">Rádio Foco</span>
                </button>
            </div>
            <div className="flex items-center gap-3">
                <div className="bg-slate-900 border border-slate-700 text-slate-400 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2">
                    <Cloud className="w-4 h-4 text-green-400"/> <span className="hidden md:inline">{user?.isAnonymous ? 'Anônimo' : 'Conectado'}</span>
                </div>
                <div className="bg-orange-900/40 border border-orange-500/50 text-orange-400 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 shadow-lg">
                    <Flame className={cn("w-4 h-4", progresso.streak > 0 && "animate-pulse")} /> 
                    <span>{streakDisplay}</span>
                </div>
            </div>
        </div>

        {/* Main Content */}
        <div className="max-w-4xl w-full z-10 mt-20 md:mt-10">
            <div className="text-center mb-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="inline-flex items-center gap-2 bg-slate-900/80 border border-green-500/30 px-5 py-2 rounded-full text-xs font-bold text-green-400 uppercase tracking-[0.2em] mb-6 shadow-[0_0_15px_rgba(34,197,94,0.15)] select-none">
                    <Satellite className="w-4 h-4" /> Conexão Global - Rede de Inteligência IA
                </div>
                <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-200 to-slate-400 mb-4 tracking-tight">
                    Gerador de Papiro <span className="text-green-500">Tático</span>
                </h1>
                <p className="text-slate-400 text-lg font-light max-w-2xl mx-auto">Gere missões inéditas, realize simulados com 5 alternativas reais e evolua a sua patente rumo à aprovação.</p>
            </div>

            <div className="glass-panel rounded-3xl p-6 md:p-10 relative overflow-hidden animate-in fade-in slide-in-from-bottom-6 duration-700">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
                    <div className="group">
                        <label className="flex items-center gap-2 text-xs font-bold text-slate-400 mb-3 uppercase tracking-widest group-hover:text-green-400 transition-colors">
                            <Target className="w-4 h-4" /> Alvo Principal (Matéria)
                        </label>
                        <select id="select-materia" value={materia} onChange={(e)=>setMateria(e.target.value)} className="custom-select w-full bg-slate-900/50 border-2 border-slate-700 text-white font-medium rounded-xl px-5 py-4 focus:outline-none focus:border-green-500 focus:ring-4 focus:ring-green-500/20 transition-all cursor-pointer shadow-inner">
                            <option value="matematica">Matemática</option>
                            <option value="portugues">Português</option>
                            <option value="literatura">Literatura</option>
                            <option value="redacao">Redação</option>
                            <option value="historia">História do Brasil</option>
                            <option value="geografia">Geografia do Brasil</option>
                            <option value="ingles">Inglês</option>
                        </select>
                    </div>
                    
                    <div className="group">
                        <label className="flex items-center gap-2 text-xs font-bold text-slate-400 mb-3 uppercase tracking-widest group-hover:text-green-400 transition-colors">
                            <Hourglass className="w-4 h-4" /> Janela de Operação (Tempo)
                        </label>
                        <select value={tempo} onChange={(e)=>setTempo(e.target.value as any)} className="custom-select w-full bg-slate-900/50 border-2 border-slate-700 text-white font-medium rounded-xl px-5 py-4 focus:outline-none focus:border-green-500 focus:ring-4 focus:ring-green-500/20 transition-all cursor-pointer shadow-inner">
                            {Object.entries(TEMPOS).map(([k, v]) => (
                                <option key={k} value={k}>{v.label}</option>
                            ))}
                        </select>
                    </div>
                </div>

                <button onClick={handleGenerate} disabled={isLoading} className={cn("btn-tactical w-full text-white font-extrabold text-lg py-5 rounded-xl flex items-center justify-center gap-3 tracking-wide", isLoading && "opacity-50 cursor-not-allowed")}>
                    {isLoading ? <Signal className="w-5 h-5 animate-spin" /> : <Signal className="w-5 h-5" />}
                    {isLoading ? "INTERCEPTANDO SINAIS..." : "INTERCEPTAR CONTEÚDO E GERAR DOSSIÊ"}
                </button>

                {isLoading && (
                    <div className="mt-8 text-center py-10 border-t border-slate-800">
                        <Globe className="w-10 h-10 animate-spin text-green-500 mb-4 mx-auto drop-shadow-[0_0_10px_rgba(34,197,94,0.5)]" />
                        <h3 className="text-lg font-bold text-white mb-2">Acessando Rede Global de Inteligência...</h3>
                        <p className="text-sm text-slate-400 font-mono">Processando matriz de dados e gerando simulado inédito...</p>
                    </div>
                )}

                {missao && !isLoading && (
                    <div className="mt-10 pt-8 border-t border-slate-800 relative animate-in fade-in slide-in-from-bottom-8">
                        <div className="scanline"></div>
                        
                        <div className="flex flex-wrap items-center justify-between mb-8 gap-4">
                            <div>
                                <div className="text-xs font-bold text-green-500 uppercase tracking-widest mb-1 flex items-center gap-2">
                                    <CloudDownload className="w-4 h-4" /> Missão Interceptada
                                </div>
                                <h3 className="text-2xl md:text-3xl font-black text-white flex items-center gap-3 capitalize">
                                    {materia}
                                </h3>
                            </div>
                            
                            <div className="flex gap-3">
                                {showLevelUp && (
                                    <div className="bg-purple-900/80 border border-purple-500 px-3 py-1.5 rounded-lg text-center shadow-[0_0_15px_rgba(168,85,247,0.4)] animate-pulse">
                                        <div className="text-[10px] text-purple-300 uppercase font-bold flex items-center gap-1 justify-center"><ArrowUp className="w-3 h-3"/> Promoção</div>
                                        <div className="text-sm font-black text-white">SUBIU NÍVEL</div>
                                    </div>
                                )}
                                <div className="bg-slate-900 border border-slate-700 px-3 py-1.5 rounded-lg text-center shadow-inner">
                                    <div className="text-[10px] text-slate-400 uppercase font-bold">Incidência</div>
                                    <div className="text-sm font-black text-red-400">{missao.incidencia || "ALTA"}</div>
                                </div>
                                <div className="bg-slate-900 border border-slate-700 px-3 py-1.5 rounded-lg text-center shadow-inner">
                                    <div className="text-[10px] text-slate-400 uppercase font-bold">Nível</div>
                                    <div className={cn("text-sm font-black", missao.nivel==='CAVEIRA'?'text-red-500':missao.nivel==='BÁSICO'?'text-green-400':'text-yellow-400')}>{missao.nivel}</div>
                                </div>
                            </div>
                        </div>

                        {/* CRONÓMETRO */}
                        <div className="bg-slate-900 border-2 border-slate-700 rounded-2xl p-5 mb-6 flex flex-col md:flex-row items-center justify-between gap-4 shadow-lg">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center border border-slate-600 shadow-inner">
                                    <Timer className={cn("w-6 h-6 text-slate-300", isTimerRunning && "animate-spin text-green-500")} />
                                </div>
                                <div>
                                    <div className="text-xs text-slate-400 font-bold uppercase tracking-widest mb-1">Cronômetro de Foco</div>
                                    <div className="text-3xl font-mono font-black text-white">{formatTime(tempoRestante)}</div>
                                </div>
                            </div>
                            <div className="flex gap-2">
                                <button onClick={toggleTimer} className={cn("text-white px-5 py-2 rounded-lg font-bold transition-colors shadow-md flex items-center gap-2", isTimerRunning ? "bg-orange-600 hover:bg-orange-500" : "bg-green-600 hover:bg-green-500")}>
                                    {isTimerRunning ? <RotateCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
                                    {isTimerRunning ? "Em Operação" : "Iniciar Foco"}
                                </button>
                                {isTimerRunning && (
                                    <button onClick={toggleTimer} className="bg-slate-700 hover:bg-slate-600 text-white px-4 py-2 rounded-lg font-bold transition-colors shadow-md flex items-center">
                                        <Pause className="w-4 h-4" />
                                    </button>
                                )}
                            </div>
                        </div>

                        <div className="space-y-6 relative z-20">
                            {/* Teoria */}
                            <div className="bg-slate-900/80 rounded-2xl p-6 border-l-4 border-blue-500 shadow-lg group">
                                <div className="flex justify-between items-start mb-4 gap-4">
                                    <h4 className="font-bold text-blue-400 text-xl flex items-center gap-2">
                                        <Brain className="w-5 h-5"/> Fase 1: Inteligência (Teoria)
                                    </h4>
                                    <span className="text-xs font-bold text-blue-300 bg-blue-900/30 border border-blue-500/20 px-3 py-1 rounded-full flex items-center min-w-fit">{TEMPOS[tempo].teoria}</span>
                                </div>
                                <div className="mb-4 inline-block bg-slate-800 px-3 py-1 rounded text-sm text-white font-medium shadow-inner border border-slate-700">
                                    <span className="text-slate-400 mr-2">Alvo Encontrado:</span> <span className="uppercase tracking-wider text-green-300 font-bold">{missao.topico}</span>
                                </div>
                                <p className="text-slate-300 leading-relaxed mb-6">{missao.teoria}</p>
                                
                                <div className="bg-slate-950/50 border border-slate-700 rounded-xl p-6 relative shadow-inner mt-4">
                                    <div className="absolute -top-3 left-6 bg-green-600 text-white text-xs font-bold px-4 py-1 rounded-full uppercase tracking-wider shadow-[0_0_10px_rgba(22,163,74,0.4)] flex items-center gap-2">
                                        <Pin className="w-3 h-3" /> Resumo Tático (IA)
                                    </div>
                                    <div className="text-sm md:text-base text-slate-200 leading-relaxed mt-2 space-y-4" dangerouslySetInnerHTML={{__html: missao.resumoTatico}}></div>
                                </div>
                            </div>

                            {/* Prática */}
                            <div className="bg-slate-900/80 rounded-2xl p-6 border-l-4 border-red-500 shadow-lg">
                                <div className="flex justify-between items-start mb-4 gap-4">
                                    <h4 className="font-bold text-red-400 text-xl flex items-center gap-2">
                                        <Target className="w-5 h-5" /> Fase 2: Combate (Simulado)
                                    </h4>
                                    <span className="text-xs font-bold text-red-300 bg-red-900/30 border border-red-500/20 px-3 py-1 rounded-full flex items-center min-w-fit">{TEMPOS[tempo].pratica}</span>
                                </div>
                                {materia === 'redacao' ? (
                                    <div className="text-slate-300 text-sm mb-6">
                                        Escreva <strong>1 redação completa sobre o eixo "{missao.topico}"</strong>. <br/><br/>
                                        <span className="text-red-300 flex items-center gap-2"><TriangleAlert className="w-4 h-4"/> Cronometre o tempo. Máximo 1 hora.</span>
                                    </div>
                                ) : (
                                    <>
                                    <div className="text-slate-300 text-sm mb-6">A Inteligência gerou um simulado Padrão ESA (5 alternativas). Responda clicando na alternativa simulando prova real.</div>
                                    <div className="space-y-6">
                                        {missao.questoes.map((q, idx) => (
                                            <div key={idx} id={`q-box-${idx}`} className="bg-slate-800 border border-slate-700 rounded-xl p-5 mb-4 shadow-sm" data-respondida="false">
                                                <div className="font-bold text-white mb-3"><span className="text-red-400">Q{idx+1}.</span> {q.enunciado}</div>
                                                <div className="space-y-2">
                                                    {['a','b','c','d','e'].map(l => (
                                                        <div key={l} id={`opt-${idx}-${l}`} onClick={() => handleQuestao(idx, l, q.correta)} className="border border-slate-700 rounded-lg p-3 text-sm text-slate-300 flex items-start gap-3 cursor-pointer hover:border-blue-500 hover:bg-blue-900/20 transition-colors">
                                                            <span className="font-bold uppercase bg-slate-900 text-slate-400 w-6 h-6 rounded flex items-center justify-center shrink-0 border border-slate-700">{l}</span>
                                                            <span className="mt-0.5">{(q as any)[l]}</span>
                                                        </div>
                                                    ))}
                                                </div>
                                                <div id={`exp-${idx}`} className="hidden mt-4 bg-slate-900 p-4 rounded-lg border-l-2 border-green-500 text-sm text-slate-300">
                                                    <strong className="text-green-400 block mb-1">Análise Tática:</strong> {q.explicacao}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                    </>
                                )}
                            </div>

                            {/* Revisão */}
                            <div className="bg-slate-900/80 rounded-2xl p-6 border-l-4 border-yellow-500 shadow-lg hover:bg-slate-800/80 transition-colors">
                                <div className="flex justify-between items-start mb-4 gap-4">
                                    <h4 className="font-bold text-yellow-400 text-xl flex items-center gap-2">
                                        <RotateCw className="w-5 h-5"/> Fase 3: Extração (Revisão)
                                    </h4>
                                    <span className="text-xs font-bold text-yellow-300 bg-yellow-900/30 border border-yellow-500/20 px-3 py-1 rounded-full flex items-center min-w-fit">{TEMPOS[tempo].revisao}</span>
                                </div>
                                <p className="text-slate-300 leading-relaxed">
                                    {materia === 'redacao' ? 'Revise sua redação buscando erros e compare com o Resumo Tático.' : 'Copie o Resumo Tático para seu caderno físico e anote os erros do combate.'}
                                </p>
                            </div>
                        </div>
                        
                        <div className="mt-8 relative p-1 rounded-2xl bg-gradient-to-r from-green-600 via-emerald-400 to-green-600 shadow-[0_0_30px_rgba(22,163,74,0.3)]">
                            <div className="bg-slate-900 rounded-xl p-6 h-full w-full">
                                <div className="flex items-center gap-3 mb-3">
                                    <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center border border-green-500 shadow-inner">
                                        <Star className="w-5 h-5 text-green-400" />
                                    </div>
                                    <h4 className="font-black text-white text-lg uppercase tracking-wide">O Bizú do General (Estratégia)</h4>
                                </div>
                                <p className="text-slate-300 font-medium leading-relaxed italic border-l-2 border-green-500/50 pl-4 ml-5">{missao.bizu}</p>
                            </div>
                        </div>

                        <div className="mt-6 flex flex-col md:flex-row gap-3 no-print">
                            <button onClick={()=>window.print()} className="flex-1 bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2 shadow-lg">
                                <FileText className="w-5 h-5 text-red-400" /> Baixar Papiro (PDF)
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </div>

        {/* Chat IA Button */}
        <button onClick={() => setShowChat(p => !p)} className="fixed bottom-6 right-6 w-16 h-16 bg-gradient-to-tr from-green-700 to-green-500 rounded-full shadow-[0_0_20px_rgba(22,163,74,0.5)] flex items-center justify-center text-white hover:scale-110 transition-all z-50 group border-2 border-green-400 no-print">
            <Bot className="w-7 h-7" />
        </button>

        {/* Chat Window */}
        <div className={cn("fixed bottom-28 right-6 w-[340px] md:w-[420px] bg-slate-900 border border-slate-700 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.8)] z-50 flex flex-col overflow-hidden no-print transition-all duration-300 origin-bottom-right", showChat ? "opacity-100 scale-100" : "opacity-0 scale-90 pointer-events-none")}>
            <div className="bg-gradient-to-r from-green-800 to-slate-900 border-b border-green-600/50 p-4 flex justify-between items-center z-10 relative">
                <div className="flex items-center gap-3 relative z-10">
                    <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center border-2 border-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]">
                        <ShieldCheck className="w-6 h-6 text-green-400" />
                    </div>
                    <div>
                        <h3 className="font-bold text-white text-lg leading-tight">Sargento IA</h3>
                        <p className="text-[10px] text-green-400 uppercase tracking-widest font-bold flex items-center gap-1">
                            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span> Online (Voz Ativa)
                        </p>
                    </div>
                </div>
                <button onClick={() => setShowChat(false)} className="text-slate-400 hover:text-white transition-colors relative z-10"><X className="w-6 h-6" /></button>
            </div>
            
            <div className="h-[60vh] max-h-[400px] overflow-y-auto p-4 space-y-4 bg-slate-950/90 scroll-smooth flex-1">
                {chatMsgs.map((m) => (
                    <div key={m.id} className={cn("flex gap-3", m.role === 'user' && "flex-row-reverse")}>
                        <div className={cn("w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-xs mt-1 shadow-inner", m.role === 'ia' ? "bg-green-800 border border-green-500" : "bg-slate-700 border border-slate-600")}>
                            {m.role === 'ia' ? <Bot className="w-4 h-4 text-green-300" /> : <User className="w-4 h-4 text-white" />}
                        </div>
                        <div className={cn("rounded-2xl p-4 text-sm shadow-sm leading-relaxed max-w-[85%]", m.role === 'ia' ? "bg-slate-800 rounded-tl-none border border-slate-700 text-slate-200" : "bg-slate-700 rounded-tr-none border border-slate-600 text-white")}>
                            <span dangerouslySetInnerHTML={{__html: m.text.replace(/\n/g, '<br/>')}}></span>
                        </div>
                    </div>
                ))}
                {isChatLoading && (
                    <div className="flex gap-3">
                        <div className="w-8 h-8 rounded-full bg-green-800 border border-green-500 flex shrink-0 items-center justify-center"><Bot className="w-4 h-4 text-green-300" /></div>
                        <div className="bg-slate-800 rounded-2xl rounded-tl-none p-3 text-sm text-slate-400 flex items-center gap-2">
                            <RotateCw className="w-4 h-4 animate-spin text-green-500" /> Processando...
                        </div>
                    </div>
                )}
                <div ref={chatBottomRef}></div>
            </div>

            <div className="p-3 bg-slate-900 border-t border-slate-700">
                <form onSubmit={sendChat} className="flex gap-2">
                    <input type="text" value={chatInput} onChange={(e)=>setChatInput(e.target.value)} placeholder="Digite sua dúvida..." className="flex-1 bg-slate-800 border border-slate-600 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-green-500" required />
                    <button type="submit" disabled={isChatLoading} className="bg-green-600 hover:bg-green-500 text-white w-12 rounded-xl flex items-center justify-center transition-all shadow-md">
                        <Send className="w-4 h-4" />
                    </button>
                </form>
            </div>
        </div>

        {/* Modal: Ficha Militar */}
        {showFicha && (
            <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center animate-in fade-in no-print">
                <div className="glass-panel w-full max-w-md rounded-2xl p-6 relative max-h-[90vh] overflow-y-auto w-[90%]">
                    <button onClick={() => setShowFicha(false)} className="absolute top-4 right-4 text-slate-400 hover:text-white"><X className="w-5 h-5"/></button>
                    
                    <div className="text-center mb-6">
                        <div className="w-20 h-20 bg-gradient-to-tr from-green-800 to-green-500 rounded-full mx-auto mb-3 flex items-center justify-center border-4 border-slate-900 shadow-[0_0_20px_rgba(34,197,94,0.3)]">
                            <Star className="w-8 h-8 text-white" />
                        </div>
                        <h2 className="text-2xl font-black text-white">{patenteData.nome}</h2>
                        <p className="text-sm text-green-400 font-bold uppercase tracking-widest mb-3">Nível Atual</p>
                    </div>

                    <div className="bg-slate-900/50 rounded-xl p-4 border border-slate-700 mb-4">
                        <div className="flex justify-between text-sm mb-2">
                            <span className="text-slate-400">Progresso para Promoção</span>
                            <span className="text-white font-bold">{Math.max(0, progresso.totalVistos - patenteData.prevMax)} / {patenteData.max - patenteData.prevMax} Tópicos</span>
                        </div>
                        <div className="w-full bg-slate-800 rounded-full h-2.5 shadow-inner">
                            <div className="bg-green-500 h-2.5 rounded-full transition-all duration-500" style={{width: `${Math.min(100, (Math.max(0, progresso.totalVistos - patenteData.prevMax) / (patenteData.max - patenteData.prevMax)) * 100)}%`}}></div>
                        </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-center mb-4">
                        <div className="bg-slate-900 border border-slate-700 p-2 rounded-xl shadow-inner">
                            <div className="text-xl font-black text-white">{progresso.totalVistos}</div>
                            <div className="text-[9px] text-slate-400 uppercase font-bold">Missões</div>
                        </div>
                        <div className="bg-slate-900 border border-slate-700 p-2 rounded-xl shadow-inner">
                            <div className="text-xl font-black text-blue-400">
                                {progresso.acertos + progresso.erros > 0 ? Math.round((progresso.acertos / (progresso.acertos + progresso.erros)) * 100) : 0}%
                            </div>
                            <div className="text-[9px] text-slate-400 uppercase font-bold">Precisão</div>
                        </div>
                        <div className="bg-slate-900 border border-slate-700 p-2 rounded-xl shadow-inner">
                            <div className="text-xl font-black text-yellow-400">
                                {Object.values(progresso.materias).reduce((a, m) => a + (m.currentLevel === 'CAVEIRA' ? 1 : 0), 0)}
                            </div>
                            <div className="text-[9px] text-slate-400 uppercase font-bold">Caveiras</div>
                        </div>
                    </div>

                    <div className="bg-slate-900/50 rounded-xl p-4 border border-slate-700 min-h-[200px]">
                        <h3 className="text-xs text-slate-400 font-bold uppercase tracking-widest mb-3 text-center">Radar Tático (Domínio)</h3>
                        <ResponsiveContainer width="100%" height={200}>
                            <RadarChart cx="50%" cy="50%" outerRadius="80%" data={getRadarData()}>
                                <PolarGrid stroke="rgba(255,255,255,0.1)" />
                                <PolarAngleAxis dataKey="subject" tick={{fill: '#94a3b8', fontSize: 10}} />
                                <Radar dataKey="A" stroke="#22c55e" fill="#22c55e" fillOpacity={0.3} />
                            </RadarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>
        )}

        {/* Modal: Alert */}
        {showAlert.show && (
            <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-[60] flex items-center justify-center animate-in fade-in">
                <div className="glass-panel w-[90%] max-w-sm rounded-2xl p-6 relative flex flex-col items-center text-center">
                    <div className="w-16 h-16 bg-red-900/50 rounded-full mb-4 flex items-center justify-center border-2 border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.4)]">
                        <TriangleAlert className="w-8 h-8 text-red-500" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">Atenção, Guerreiro!</h3>
                    <p className="text-sm text-slate-300 mb-6">{showAlert.msg}</p>
                    <button onClick={() => setShowAlert({show: false, msg: ""})} className="bg-red-600 hover:bg-red-500 text-white font-bold py-2 px-6 rounded-lg transition-colors w-full">
                        Entendido
                    </button>
                </div>
            </div>
        )}

        {/* Modal: Auth (Dummy simulation as requested in original) */}
        {showAuth && (
            <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-[70] flex items-center justify-center animate-in fade-in no-print">
                <div className="glass-panel w-[90%] max-w-sm rounded-2xl p-6 relative flex flex-col">
                    <button onClick={() => setShowAuth(false)} className="absolute top-4 right-4 text-slate-400 hover:text-white"><X className="w-5 h-5"/></button>
                    
                    <div className="text-center mb-6">
                        <div className="w-16 h-16 bg-blue-900/50 rounded-full mx-auto mb-3 flex items-center justify-center border-2 border-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.4)]">
                            <UserPlus className="w-8 h-8 text-blue-400" />
                        </div>
                        <h3 className="text-xl font-bold text-white mb-1">{isLoginMode ? "Acesso ao QG" : "Alistamento"}</h3>
                        <p className="text-xs text-slate-400">{isLoginMode ? "Entre com credenciais (Mock)" : "Crie uma conta"}</p>
                    </div>
                    
                    <form onSubmit={(e) => { e.preventDefault(); setShowAuth(false); setShowAlert({show:true, msg: "Auth via rede em manutenção! Operando offline."}); }} className="space-y-4">
                        <div>
                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">E-mail</label>
                            <input type="email" required className="w-full bg-slate-800 border border-slate-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500" />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Senha</label>
                            <input type="password" required className="w-full bg-slate-800 border border-slate-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500" />
                        </div>
                        <button type="submit" className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-lg transition-colors mt-2">
                            {isLoginMode ? "ENTRAR" : "CRIAR CONTA"}
                        </button>
                    </form>
                    
                    <div className="mt-4 text-center">
                        <button onClick={() => setIsLoginMode(!isLoginMode)} type="button" className="text-xs text-slate-400 hover:text-white transition-colors">
                            {isLoginMode ? "Novo recruta? Aliste-se aqui" : "Já possui conta? Entre aqui"}
                        </button>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
}
