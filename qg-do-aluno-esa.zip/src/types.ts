export interface ProgressoMateria {
  seen: string[];
  currentLevel: 'BÁSICO' | 'PADRÃO' | 'CAVEIRA';
}

export interface ProgressoAluno {
  totalVistos: number;
  acertos: number;
  erros: number;
  streak: number;
  lastStudyDate: string | null;
  materias: Record<string, ProgressoMateria>;
}

export interface Questao {
  enunciado: string;
  a: string;
  b: string;
  c: string;
  d: string;
  e: string;
  correta: string;
  explicacao: string;
}

export interface DossieMissao {
  materia: string;
  topico: string;
  incidencia: string;
  nivel: string;
  teoria: string;
  resumoTatico: string;
  bizu: string;
  questoes: Questao[];
}
