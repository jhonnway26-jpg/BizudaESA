import { GoogleGenAI, Type } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function generateDossie(materia: string, nivel: string, topicosVistos: string[]) {
  const listaVistos = topicosVistos.length > 0 ? topicosVistos.join(', ') : 'Nenhum';
  const prompt = `Aja como Sargento instrutor da ESA.
Materia: ${materia}. Dificuldade: ${nivel}. Evitar: [${listaVistos}].
Gere um tópico inédito da ESA.
O simulado deve ter EXATAMENTE 5 QUESTÕES inéditas com 5 ALTERNATIVAS (a, b, c, d, e) cada.
Retorne de acordo com o JSON Schema exigido.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: "Você é instrutor ESA. Retorne APENAS JSON válido sem marcação markdown e seguindo estritamente a estrutura solicitada.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            topico: { type: Type.STRING },
            incidencia: { type: Type.STRING, description: "EX: ALTA, MÉDIA, BAIXA" },
            nivel: { type: Type.STRING },
            teoria: { type: Type.STRING, description: "Teoria tática em 2 parágrafos" },
            resumoTatico: { type: Type.STRING, description: "Resumo usando HTML e TailwindCSS classes" },
            bizu: { type: Type.STRING, description: "Dica de ouro curta" },
            questoes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  enunciado: { type: Type.STRING },
                  a: { type: Type.STRING },
                  b: { type: Type.STRING },
                  c: { type: Type.STRING },
                  d: { type: Type.STRING },
                  e: { type: Type.STRING },
                  correta: { type: Type.STRING, description: "letra correta: a, b, c, d, ou e" },
                  explicacao: { type: Type.STRING }
                },
                required: ["enunciado", "a", "b", "c", "d", "e", "correta", "explicacao"]
              }
            }
          },
          required: ["topico", "incidencia", "nivel", "teoria", "resumoTatico", "bizu", "questoes"]
        }
      }
    });

    if (!response.text) throw new Error("A Inteligência não retornou dados.");
    return JSON.parse(response.text);
  } catch (err: any) {
    console.error("Gemini Error:", err);
    throw new Error("Falha na comunicação com a IA: " + err.message);
  }
}

export async function chatGemini(message: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: message,
      config: {
        systemInstruction: "Você é Sargento IA da ESA. Responda taticamente às perguntas do aluno (dúvidas de matérias, militarismo, etc)."
      }
    });
    return response.text || "Sem resposta da inteligência central.";
  } catch (err: any) {
    throw new Error("Negativo. Falha de rádio: " + err.message);
  }
}
