import { initializeApp, getApps } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyCmbO4oTcKgLgx4qyPlDjn-cYpUJJo5bcg",
  authDomain: "qg-esa.firebaseapp.com",
  projectId: "qg-esa",
  storageBucket: "qg-esa.firebasestorage.app",
  messagingSenderId: "780206241148",
  appId: "1:780206241148:web:421df6567eb6ce1411a0f9"
};

export const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
export const auth = getAuth(app);
export const db = getFirestore(app);
