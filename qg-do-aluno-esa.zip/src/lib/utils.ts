import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Audio setup
let sfxCtx: AudioContext | null = null;
export function initSFX() {
    if(!sfxCtx) {
        sfxCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if(sfxCtx.state === 'suspended') sfxCtx.resume();
}

function playTone(freq: number, type: OscillatorType, duration: number, vol = 0.1) {
    initSFX(); 
    if(!sfxCtx) return;
    const osc = sfxCtx.createOscillator(); 
    const gain = sfxCtx.createGain();
    osc.type = type; 
    osc.frequency.setValueAtTime(freq, sfxCtx.currentTime);
    gain.gain.setValueAtTime(vol, sfxCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, sfxCtx.currentTime + duration);
    osc.connect(gain); 
    gain.connect(sfxCtx.destination);
    osc.start(); 
    osc.stop(sfxCtx.currentTime + duration);
}

export function playSfxClick() { playTone(1200, 'square', 0.05, 0.02); }
export function playSfxCorrect() { playTone(600, 'sine', 0.1, 0.1); setTimeout(()=>playTone(800, 'sine', 0.2, 0.1), 100); }
export function playSfxWrong() { playTone(300, 'sawtooth', 0.3, 0.1); }
export function playSfxLevelUp() { [300,400,500,600,800].forEach((f,i)=>setTimeout(()=>playTone(f,'square',0.1,0.05), i*100)); }

export function falarTexto(textoLimpo: string) {
    if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(textoLimpo);
        u.lang = 'pt-BR'; u.rate = 1.1; u.pitch = 0.9;
        window.speechSynthesis.speak(u);
    }
}
